def normalize_labels(values):
    result = []
    seen = set()

    for value in values:
        label = value.strip().lower()
        if label and label not in seen:
            seen.add(label)
            result.append(label)

    return result
