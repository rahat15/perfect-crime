def normalize_labels(values):
    labels = []
    seen = set()

    for value in values:
        label = value.strip().lower()
        if label and label not in seen:
            seen.add(label)
            labels.append(label)

    return labels
