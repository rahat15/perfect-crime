def normalize_labels(values):
    """Normalize labels, preserving the first occurrence of each nonempty label."""
    result = []
    seen = set()
    for value in values:
        label = value.strip().lower()
        if label and label not in seen:
            seen.add(label)
            result.append(label)
    return result
