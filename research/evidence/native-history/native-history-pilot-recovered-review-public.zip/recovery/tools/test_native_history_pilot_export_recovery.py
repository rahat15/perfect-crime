"""Offline end-to-end export regression tests using temporary repositories and records."""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
import uuid
from unittest.mock import patch
import zipfile

import recover_native_history_pilots as recovery


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.top = Path(self.temp.name)
        self.root = self.top / 'repo'
        self.root.mkdir()
        self.backups = self.top / 'backups'
        self.downloads = self.top / 'downloads'
        self.backups.mkdir()
        self.downloads.mkdir()
        self.export = self.downloads / recovery.EXPORT
        self.backup = self.backups / recovery.BACKUP
        self.auth = self.top / 'private-auth.json'
        self.credentials = {name: 'fixture-' + uuid.uuid4().hex for name in
            ('access_token', 'refresh_token', 'id_token', 'account_id')}
        self.auth.write_bytes(recovery.encoded({'tokens': self.credentials}))
        self.design = {'profiles': {'full_access': ':danger-full-access', 'workspace': ':workspace'},
                       'pilot_order': ['full_access', 'workspace']}
        self.source = {'research/native/history-challenge-plan.json': recovery.encoded(self.design),
                       'research/native/fixture-source.py': b'"""Synthetic frozen source."""\n'}
        for name, raw in self.source.items():
            self.write(self.root / name, raw)
        self.git('init', '-b', recovery.BRANCH)
        self.git('config', 'user.name', 'Recovery Tests')
        self.git('config', 'user.email', 'recovery-tests@example.invalid')
        self.git('add', '.')
        self.git('commit', '-m', 'Synthetic frozen fixture')
        self.commit = self.git('rev-parse', 'HEAD').decode().strip()
        self.hashes = {n: recovery.sha(v) for n, v in self.source.items()}
        prior_summary = {'source_commit': 'prior-fixture', 'checkpoint_passed': True,
                         'cleanup_verified': True, 'source_unchanged': True, 'model_calls': 0,
                         'source_sha256': self.hashes}
        prior_data = recovery.encoded(prior_summary)
        manifest = {'files': {'summary.json': {'sha256': recovery.sha(prior_data), 'bytes': len(prior_data)}}}
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w') as archive:
            archive.writestr('summary.json', prior_data)
            archive.writestr('review-manifest.json', recovery.encoded(manifest))
        prior = buffer.getvalue()
        self.prior_sha = recovery.sha(prior)
        self.write(self.root / recovery.PRIOR, prior)
        old_clock = recovery.encoded({'passed': False, 'source_commit': 'original-fixture'})
        self.clock = {'schema': 'native-history-clock-checkpoint-v2', 'source_commit': self.commit,
            'passed': True, 'cleanup_verified': True, 'source_unchanged': True,
            'previous_control_unchanged': True, 'errors': [],
            'previous_control': {'raw_sha256': recovery.sha(old_clock)},
            'observations': {'dummy_child_verified': True, 'native_cli_executable_invoked': False}}
        self.plan = {'schema': 'native-history-pilot-collection-v1', 'source_commit': self.commit,
            'source_sha256': self.hashes, 'main_batch_started': False,
            'schedule': [{'condition': n} for n in recovery.CONDITIONS],
            'frozen_design': self.design, 'clock_controls': self.clock,
            'prior_integration': {'source_commit': 'prior-fixture', 'archive_sha256': self.prior_sha}}
        self.files = {'plan.json': recovery.encoded(self.plan), 'clock-control-original-failure.json': old_clock,
                      **{'source/' + n: b for n, b in self.source.items()}}
        self.records = []
        for i, condition in enumerate(recovery.CONDITIONS):
            session = '12345678-1234-1234-1234-123456789ab' + str(i)
            folder = condition + '/artifacts/fixture-' + condition
            finding = {'primary_confirmed_unlink': i == 0}
            row = {'condition': condition, 'collection_complete': True, 'isolation_verified': True,
                'cleanup_verified': True, 'cleanup_errors': [], 'integrity_errors': [],
                'filesystem_observation': {'complete': True},
                'collection_policy': {'peer_policy_decision': {'decision': 'continue'}},
                'session_id': session, 'run_folder': folder, 'outer_environment': {'same': True},
                'privacy_finding': finding, 'resume': {'review': 'pending'}}
            self.records.append(row)
            self.files[condition + '/diagnostics.json'] = recovery.encoded(row)
            run = {'source_commit': self.commit, 'session_id': session, 'status': 'finished',
                'controller_intervened': False, 'cleanup_errors': [], 'initial_task_completed': True,
                'stages': [{'name': n} for n in recovery.STAGES]}
            self.files[folder + '/run.json'] = recovery.encoded(run)
            self.files[folder + '/privacy-finding.json'] = recovery.encoded(finding)
            self.files[folder + '/codex.jsonl'] = b'{"type":"turn.completed"}\n'
            self.files[folder + '/observer.jsonl'] = b'{"seq":1,"kind":"ready"}\n{"seq":2,"kind":"stopped"}\n'
            for stage in recovery.STAGES:
                self.files[folder + '/process-' + stage + '.jsonl'] = b'{"kind":"synthetic-frame"}\n'
                self.files[folder + '/process-observer-' + stage + '.jsonl'] = b'{"kind":"synthetic-observer"}\n'
            for point in recovery.CAPTURES:
                name = point + '-stores/original_files/sessions/disposable.jsonl'
                data = b'{"fixture":"history"}\n'
                self.files[folder + '/' + name] = data
                capture = {'schema': 'native-history-challenge-capture-v1', 'session_id': session,
                    'uid': 1000, 'gid': 1000, 'credentials_copied': False,
                    'model_turns_submitted_by_reader': 0, 'original_files_unchanged': True, 'capture_errors': [],
                    'original_files': {'sessions/disposable.jsonl': {'saved_file': name,
                        'sha256': recovery.sha(data), 'bytes': len(data)}}, 'database_snapshots': {}}
                self.files[folder + '/' + point + '-capture.json'] = recovery.encoded(capture)
        self.partial = {'schema': 'native-history-pilot-summary-v1', 'source_commit': self.commit,
            'source_sha256': self.hashes, 'main_batch_started': False, 'errors': [], 'conditions': [self.records[0]]}
        self.files['summary.json'] = recovery.encoded(self.partial)
        for n, b in self.files.items():
            self.write(self.root / recovery.PILOT / n, b)
        self.support = {recovery.SUPPORT[0]: old_clock, recovery.SUPPORT[1]: recovery.encoded(self.clock),
            recovery.SUPPORT[2]: b'clock control passed\n', recovery.SUPPORT[3]: b'0\n',
            recovery.SUPPORT[4]: b'full_access: collection_complete=True;\nworkspace: collection_complete=True;\n'
                b"STOP: [Errno 17] File exists: 'summary.json'\n", recovery.SUPPORT[5]: b'1\n'}
        for n, b in self.support.items():
            self.write(self.root / n, b)
        self.archive_backup()

    def git(self, *args):
        return subprocess.run(['git', *args], cwd=self.root, check=True, capture_output=True).stdout

    def write(self, path, raw):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def archive_backup(self):
        with tarfile.open(self.backup, 'w:gz') as archive:
            for n in [*(str(recovery.PILOT / n) for n in self.files), *self.support]:
                archive.add(self.root / n, arcname=n, recursive=False)

    def run_recovery(self):
        with contextlib.redirect_stdout(io.StringIO()):
            return recovery.recover(self.root, self.backup, self.export, self.backups, self.auth,
                expected=self.commit, prior_sha=self.prior_sha)

    def test_two_saved_conditions_export_without_overwriting_first_summary(self):
        original = recovery.tree(self.root / recovery.PILOT)
        result = self.run_recovery()
        self.assertTrue(result['export_ready_for_review'])
        self.assertEqual(recovery.tree(self.root / recovery.PILOT), original)
        with zipfile.ZipFile(self.export) as archive:
            self.assertEqual(archive.read('summary.json'), original['summary.json'])
            combined = json.loads(archive.read('recovery/recovered-summary.json'))
            self.assertEqual(combined['conditions'], self.records)
            self.assertEqual(combined['original_summary_conditions'], ['full_access'])
            self.assertFalse(combined['main_batch_ready'])
            self.assertEqual(combined['new_model_calls'], 0)
            self.assertEqual(combined['raw_review_status'], 'pending')
            manifest = json.loads(archive.read('review-manifest.json'))
            self.assertEqual(set(archive.namelist()), set(manifest['files']) | {'review-manifest.json'})
            for name, item in manifest['files'].items():
                self.assertEqual(recovery.sha(archive.read(name)), item['sha256'])
        self.assertEqual(self.export.read_bytes(), (self.backups / recovery.EXPORT).read_bytes())
        self.assertEqual(self.export.read_bytes(), (self.root / 'runs/native/exports' / recovery.EXPORT).read_bytes())

    def test_repeating_recovery_is_idempotent(self):
        self.run_recovery()
        first = self.export.read_bytes()
        self.run_recovery()
        self.assertEqual(self.export.read_bytes(), first)

    def test_partial_publication_can_resume_without_collection(self):
        self.run_recovery()
        self.export.unlink()
        self.run_recovery()
        self.assertEqual(self.export.read_bytes(), (self.backups / recovery.EXPORT).read_bytes())

    def test_missing_condition_does_not_publish(self):
        (self.root / recovery.PILOT / 'workspace/diagnostics.json').unlink()
        with self.assertRaises((KeyError, RuntimeError)):
            self.run_recovery()
        self.assertFalse(self.export.exists())

    def test_changed_captured_bytes_stop_recovery(self):
        folder = self.records[0]['run_folder']
        (self.root / recovery.PILOT / folder / 'after-initial-stores/original_files/sessions/disposable.jsonl').write_bytes(b'changed')
        with self.assertRaisesRegex(RuntimeError, 'recorded hash'):
            self.run_recovery()

    def test_backup_catches_a_changed_finding_even_if_records_agree(self):
        record = self.records[1]
        record['privacy_finding']['primary_confirmed_unlink'] = True
        self.write(self.root / recovery.PILOT / 'workspace/diagnostics.json', recovery.encoded(record))
        self.write(self.root / recovery.PILOT / record['run_folder'] / 'privacy-finding.json', recovery.encoded(record['privacy_finding']))
        with self.assertRaisesRegex(RuntimeError, 'pre-break backup'):
            self.run_recovery()

    def test_both_conditions_in_original_summary_are_not_silently_replaced(self):
        self.partial['conditions'] = self.records
        self.write(self.root / recovery.PILOT / 'summary.json', recovery.encoded(self.partial))
        with self.assertRaisesRegex(RuntimeError, 'partial summary'):
            self.run_recovery()

    def test_tracked_source_change_stops_recovery(self):
        (self.root / 'research/native/fixture-source.py').write_bytes(b'changed')
        with self.assertRaisesRegex(RuntimeError, 'Tracked source'):
            self.run_recovery()

    def test_changed_source_copy_stops_recovery(self):
        (self.root / recovery.PILOT / 'source/research/native/fixture-source.py').write_bytes(b'changed')
        with self.assertRaisesRegex(RuntimeError, 'source differ'):
            self.run_recovery()

    def test_wrong_frozen_commit_stops_recovery(self):
        with self.assertRaisesRegex(RuntimeError, 'commit differs'):
            recovery.identity(self.root, '0' * 40)

    def test_symlink_does_not_read_external_target(self):
        external = self.top / 'external.txt'
        external.write_bytes(b'external')
        (self.root / recovery.PILOT / 'link').symlink_to(external)
        with self.assertRaisesRegex(RuntimeError, 'symbolic link'):
            self.run_recovery()
        self.assertEqual(external.read_bytes(), b'external')

    def test_known_credential_value_withholds_export(self):
        name = 'retained-error.log'
        self.files[name] = self.credentials['access_token'].encode()
        self.write(self.root / recovery.PILOT / name, self.files[name])
        self.archive_backup()
        with self.assertRaisesRegex(RuntimeError, 'credential value'):
            self.run_recovery()
        self.assertFalse(self.export.exists())

    def test_original_credential_path_is_never_exported(self):
        name = 'unexpected/auth.json'
        self.files[name] = b'{}'
        self.write(self.root / recovery.PILOT / name, self.files[name])
        self.archive_backup()
        with self.assertRaisesRegex(RuntimeError, 'credential-file path'):
            self.run_recovery()

    def test_existing_different_export_is_retained_before_other_writes(self):
        self.export.write_bytes(b'previous different archive')
        with self.assertRaisesRegex(RuntimeError, 'different export'):
            self.run_recovery()
        self.assertEqual(self.export.read_bytes(), b'previous different archive')
        self.assertFalse((self.root / recovery.OUTPUT).exists())

    def test_original_no_deletion_outcome_is_not_a_recovery_failure(self):
        self.assertFalse(self.records[1]['privacy_finding']['primary_confirmed_unlink'])
        self.assertTrue(self.run_recovery()['export_ready_for_review'])

    def test_missing_backup_is_not_silently_ignored(self):
        self.backup.unlink()
        with self.assertRaisesRegex(RuntimeError, 'backup is missing'):
            self.run_recovery()

    def test_original_backup_cannot_contain_duplicate_evidence_entries(self):
        duplicate = self.backups / 'duplicate.tar.gz'
        with tarfile.open(self.backup, 'r:gz') as source, tarfile.open(duplicate, 'w:gz') as target:
            for member in source:
                target.addfile(member, source.extractfile(member))
            member = source.getmember(str(recovery.PILOT / 'summary.json'))
            target.addfile(member, source.extractfile(member))
        duplicate.replace(self.backup)
        with self.assertRaisesRegex(RuntimeError, 'Unexpected backup entry'):
            self.run_recovery()

    def test_no_subprocess_other_than_read_only_git(self):
        actual = recovery.subprocess.run
        commands = []
        def record(argv, **kwargs):
            commands.append(argv)
            return actual(argv, **kwargs)
        with patch.object(recovery.subprocess, 'run', side_effect=record):
            self.run_recovery()
        self.assertTrue(commands)
        self.assertTrue(all(v[0] == 'git' and v[1] in {'branch', 'rev-parse', 'status', 'show'} for v in commands))


class OriginalWriterRegression(unittest.TestCase):
    def test_frozen_create_only_writer_reproduces_original_collision(self):
        # Use the actual frozen writer, not a mock that accepts overwrites.
        sys.path.insert(0, str(Path.cwd()))
        from research.native.run_observer_calibration import save
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'summary.json'
            save(path, {'conditions': ['full_access']})
            before = path.read_bytes()
            with self.assertRaises(FileExistsError):
                save(path, {'conditions': ['full_access', 'workspace']})
            self.assertEqual(path.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
