"""Recover an interrupted pilot export from immutable local records, without collection."""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/home/quatinx/cse227/perfect-crime-repro')
BASE = '0701756b4408f2aff3d14fd4759ceb41c3fb818a'
BRANCH = 'native-history-defense'
PILOT = Path('runs/native/history-challenge-pilot-01')
OUTPUT = Path('runs/native/history-pilot-export-recovery-01')
EXPORT = 'native-history-pilot-recovered-review.zip'
BACKUPS = Path('/mnt/c/Users/ihaxQ/Documents/CSE227-Backups')
BACKUP = 'native-history-pilots-20261118T170257503658Z.tar.gz'
PRIOR = Path('runs/native/exports/native-history-integration-review.zip')
PRIOR_SHA = '9a67fe8ce81a835cc42a41ccace291cb646d68e2987dd983bd00fe90fccd70e1'
CONDITIONS = ('full_access', 'workspace')
STAGES = ('initial-task', 'privacy-request', 'resume')
CAPTURES = ('after-initial', 'after-privacy', 'after-resume')
TOOLS = ('recover_native_history_pilots.py', 'test_native_history_pilot_export_recovery.py',
         'export-recovery-notes.md')
SUPPORT = ('runs/native/history-clock-controls-01.json', 'runs/native/history-clock-controls-02.json',
           'runs/native/setup/history-clock-controls-02.log',
           'runs/native/setup/history-clock-controls-02-exit-code.txt',
           'runs/native/setup/native-history-pilot-01.log',
           'runs/native/setup/native-history-pilot-exit-code.txt')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(path):
    return not any(p.is_symlink() for p in (path, *path.parents))


def relative(name):
    require(isinstance(name, str) and name and '\\' not in name and '\x00' not in name,
            'Invalid evidence path.')
    value = PurePosixPath(name)
    require(not value.is_absolute() and '..' not in value.parts and '.' not in value.parts
            and value.as_posix() == name, 'Unsafe evidence path: ' + name)
    return Path(*value.parts)


def read(path):
    require(safe(path) and path.is_file() and stat.S_ISREG(path.stat().st_mode),
            'Missing or unsafe input: ' + str(path))
    return path.read_bytes()


def parse(raw):
    value = json.loads(raw)
    require(isinstance(value, dict), 'Expected a JSON object.')
    return value


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def tree(folder):
    require(safe(folder) and folder.is_dir(), 'The original pilot folder is missing or unsafe.')
    files = {}
    for path in sorted(folder.rglob('*')):
        require(safe(path), 'A symbolic link was retained without exporting: ' + str(path))
        if path.is_dir():
            continue
        require(stat.S_ISREG(path.stat().st_mode), 'A nonregular evidence file was retained.')
        files[path.relative_to(folder).as_posix()] = read(path)
    require(files, 'The original pilot folder is empty.')
    return files


def git(root, *args):
    result = subprocess.run(['git', *args], cwd=root, capture_output=True, check=False)
    require(result.returncode == 0, 'A local Git read failed: ' + args[0])
    return result.stdout


def identity(root, expected):
    require(git(root, 'branch', '--show-current').decode().strip() == BRANCH, 'Unexpected branch.')
    require(git(root, 'rev-parse', 'HEAD').decode().strip() == expected, 'The frozen pilot commit differs.')
    require(not git(root, 'status', '--porcelain', '--untracked-files=no').strip(),
            'Tracked source has changed. It was retained; no export was made.')


def json_lines(raw):
    rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
    require(rows and all(isinstance(v, dict) for v in rows), 'A required JSONL stream is empty or invalid.')
    return rows


def checked_capture(files, run_folder, point, session):
    prefix = run_folder + '/'
    value = parse(files[prefix + point + '-capture.json'])
    require(value.get('schema') == 'native-history-challenge-capture-v1'
            and value.get('session_id') == session and value.get('uid') == value.get('gid') == 1000
            and value.get('credentials_copied') is False
            and value.get('model_turns_submitted_by_reader') == 0
            and value.get('original_files_unchanged') is True and value.get('capture_errors') == [],
            'A retained capture has an unresolved integrity condition: ' + point)
    count = 0
    for category in ('original_files', 'database_snapshots'):
        require(isinstance(value.get(category), dict), 'A capture file index is missing.')
        for item in value[category].values():
            name = relative(item['saved_file']).as_posix()
            require(name.startswith(point + '-stores/' + category + '/')
                    and 'auth.json' not in relative(name).parts, 'Unexpected captured file reference.')
            raw = files[prefix + name]
            require(sha(raw) == item['sha256'] and len(raw) == item['bytes'],
                    'Captured file bytes differ from their original recorded hash: ' + name)
            count += 1
    return count


def verify_records(root, files, expected):
    plan, partial = parse(files['plan.json']), parse(files['summary.json'])
    require(plan.get('schema') == 'native-history-pilot-collection-v1'
            and plan.get('source_commit') == expected and plan.get('main_batch_started') is False,
            'The original pilot plan differs from the expected collection.')
    require([v.get('condition') for v in plan.get('schedule', [])] == list(CONDITIONS),
            'Expected exactly the two original pilot conditions.')
    require(partial.get('schema') == 'native-history-pilot-summary-v1'
            and partial.get('source_commit') == expected and partial.get('main_batch_started') is False
            and partial.get('source_sha256') == plan.get('source_sha256') and partial.get('errors') == [],
            'The retained partial summary differs.')
    hashes = plan.get('source_sha256')
    require(isinstance(hashes, dict) and hashes, 'The frozen source inventory is missing.')
    require({n[7:] for n in files if n.startswith('source/')} == set(hashes),
            'The collected source inventory is incomplete or contains an unexpected file.')
    for name, digest in hashes.items():
        rel = relative(name)
        raw = files['source/' + name]
        require(sha(raw) == digest and read(root / rel) == raw
                and git(root, 'show', expected + ':' + name) == raw,
                'Collected, current, and committed source differ: ' + name)
    design_path = 'research/native/history-challenge-plan.json'
    require(parse(files['source/' + design_path]) == plan.get('frozen_design'),
            'The recorded challenge design differs from its frozen source.')
    records, capture_files = [], 0
    for condition in CONDITIONS:
        record = parse(files[condition + '/diagnostics.json'])
        require(record.get('condition') == condition and record.get('collection_complete') is True
                and record.get('isolation_verified') is True and record.get('cleanup_verified') is True
                and record.get('cleanup_errors') == [] and record.get('integrity_errors') == []
                and record.get('filesystem_observation', {}).get('complete') is True
                and record.get('collection_policy', {}).get('peer_policy_decision', {}).get('decision') == 'continue',
                'A pilot has an unresolved collection condition: ' + condition)
        rel = relative(record['run_folder'])
        require(len(rel.parts) == 3 and rel.parts[:2] == (condition, 'artifacts'), 'Unexpected run folder.')
        folder = rel.as_posix()
        run = parse(files[folder + '/run.json'])
        require(run.get('source_commit') == expected and run.get('session_id') == record.get('session_id')
                and isinstance(record.get('session_id'), str) and record['session_id']
                and run.get('status') == 'finished' and run.get('controller_intervened') is False
                and run.get('cleanup_errors') == [] and run.get('initial_task_completed') is True
                and [v.get('name') for v in run.get('stages', [])] == list(STAGES),
                'Native run metadata is incomplete or inconsistent: ' + condition)
        json_lines(files[folder + '/codex.jsonl'])
        observer = json_lines(files[folder + '/observer.jsonl'])
        require([v.get('seq') for v in observer] == list(range(1, len(observer) + 1))
                and observer[0].get('kind') == 'ready' and observer[-1].get('kind') == 'stopped'
                and not any(v.get('kind') == 'gap' for v in observer), 'The filesystem observer has a gap.')
        for stage in STAGES:
            json_lines(files[folder + '/process-' + stage + '.jsonl'])
            json_lines(files[folder + '/process-observer-' + stage + '.jsonl'])
        for point in CAPTURES:
            capture_files += checked_capture(files, folder, point, record['session_id'])
        require(parse(files[folder + '/privacy-finding.json']) == record.get('privacy_finding'),
                'The retained privacy finding differs from the condition record.')
        records.append(record)
    require(partial.get('conditions') == [records[0]],
            'The partial summary is not the retained first-pilot summary. It was not replaced.')
    require(records[0]['session_id'] != records[1]['session_id'], 'The pilots did not use distinct sessions.')
    require(bool(records[0].get('outer_environment'))
            and records[0]['outer_environment'] == records[1].get('outer_environment'),
            'The recorded outer environments differ or are missing.')
    return plan, partial, records, capture_files


def verify_prior(root, plan, expected_sha=PRIOR_SHA):
    raw = read(root / PRIOR)
    require(sha(raw) == expected_sha == plan['prior_integration']['archive_sha256'],
            'The preceding integration archive differs.')
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        manifest = parse(package.read('review-manifest.json'))
        names = package.namelist()
        require(len(names) == len(set(names)) and set(names) == set(manifest['files']) | {'review-manifest.json'}
                and package.testzip() is None, 'The integration archive has an integrity error.')
        for name, item in manifest['files'].items():
            relative(name)
            data = package.read(name)
            require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'A prior archived file differs.')
        previous = parse(package.read('summary.json'))
        require(previous.get('checkpoint_passed') is True and previous.get('cleanup_verified') is True
                and previous.get('source_unchanged') is True and previous.get('model_calls') == 0
                and previous.get('source_commit') == plan['prior_integration']['source_commit'],
                'The preceding integration checkpoint is incomplete.')
        for name, digest in previous['source_sha256'].items():
            require(sha(read(root / relative(name))) == digest, 'Frozen integration source changed: ' + name)
    return raw


def verify_support(root, plan, files, expected):
    support = {name: read(root / name) for name in SUPPORT}
    clock = parse(support[SUPPORT[1]])
    require(clock == plan.get('clock_controls') and clock.get('source_commit') == expected
            and clock.get('schema') == 'native-history-clock-checkpoint-v2'
            and clock.get('passed') is True and clock.get('cleanup_verified') is True
            and clock.get('source_unchanged') is True and clock.get('previous_control_unchanged') is True
            and clock.get('errors') == [] and clock.get('observations', {}).get('dummy_child_verified') is True
            and clock.get('observations', {}).get('native_cli_executable_invoked') is False,
            'The corrected clock control differs from the collected plan.')
    original = support[SUPPORT[0]]
    require(original == files['clock-control-original-failure.json']
            and sha(original) == clock['previous_control']['raw_sha256'], 'The original failed control differs.')
    require(support[SUPPORT[3]].strip() == b'0' and support[SUPPORT[5]].strip() == b'1',
            'The retained command exit codes differ from the reviewed interruption.')
    log = support[SUPPORT[4]].decode('utf-8')
    require("STOP: [Errno 17] File exists:" in log and 'summary.json' in log,
            'The terminal log does not record the reviewed export interruption.')
    for condition in CONDITIONS:
        require(condition + ': collection_complete=True;' in log,
                'The terminal log is missing a completed pilot: ' + condition)
    return support


def anchored_backup(path, expected_files):
    require(safe(path) and path.is_file(), 'The verified pre-break backup is missing or unsafe.')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    found = {}
    with tarfile.open(path, 'r|gz') as archive:
        for member in archive:
            if member.name not in expected_files:
                continue
            require(member.name not in found and member.isfile(), 'Unexpected backup entry: ' + member.name)
            stream = archive.extractfile(member)
            require(stream is not None, 'Unreadable backup entry.')
            h = hashlib.sha256()
            with stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(block)
            found[member.name] = {'sha256': h.hexdigest(), 'bytes': member.size}
    expected = {name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in expected_files.items()}
    require(found == expected, 'Current pilot evidence or support logs differ from the pre-break backup.')
    return {'filename': path.name, 'sha256': digest.hexdigest(), 'verified_files': len(found),
            'all_selected_files_match': True}


def secret_values(path):
    # Values stay in memory for a local exclusion check and are never exported.
    value = parse(read(path))
    tokens = value.get('tokens', {})
    names = ('access_token', 'refresh_token', 'id_token', 'account_id')
    require(isinstance(tokens, dict) and all(isinstance(tokens.get(k), str) and len(tokens[k]) >= 8 for k in names),
            'The local subscription cache cannot support the export exclusion check. No login was attempted.')
    values = [tokens[k].encode() for k in names]
    key = value.get('OPENAI_API_KEY')
    if isinstance(key, str) and len(key) >= 8:
        values.append(key.encode())
    return values


def scan(payload, secrets):
    for name, raw in payload.items():
        require('auth.json' not in relative(name).parts, 'A credential-file path was excluded from export.')
        require(not any(value in raw for value in secrets),
                'A known local credential value was found. Export withheld; originals retained.')


def same_or_new(path, raw):
    require(safe(path), 'An output path contains a symbolic link.')
    if path.exists():
        require(read(path) == raw, 'A different existing output was retained: ' + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    require(read(path) == raw, 'Output verification failed: ' + str(path))


def zip_bytes(payload):
    contents = dict(payload)
    contents['review-manifest.json'] = encoded({'schema': 'native-history-pilot-recovered-review-v1',
        'files': {n: {'sha256': sha(v), 'bytes': len(v)} for n, v in sorted(payload.items())}})
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as package:
        for name, raw in sorted(contents.items()):
            relative(name)
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            package.writestr(entry, raw)
    raw = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        require(package.testzip() is None and len(package.namelist()) == len(contents)
                and set(package.namelist()) == set(contents)
                and all(package.read(n) == v for n, v in contents.items()), 'Recovery archive verification failed.')
    return raw


def recover(root, source_backup, export, backups, auth, *, expected=BASE, prior_sha=PRIOR_SHA, tools_dir=None):
    identity(root, expected)
    require(export.name == EXPORT and export.parent.is_dir() and backups.is_dir(), 'Unexpected export or backup path.')
    print('Checking the two existing pilot folders; no model or Docker calls.', flush=True)
    originals = tree(root / PILOT)
    plan, partial, records, capture_count = verify_records(root, originals, expected)
    prior = verify_prior(root, plan, prior_sha)
    support = verify_support(root, plan, originals, expected)
    inputs = {**{(PILOT / name).as_posix(): raw for name, raw in originals.items()}, **support}
    print('Comparing pilot evidence with the verified pre-break backup.', flush=True)
    anchor = anchored_backup(source_backup, inputs)
    helper_dir = tools_dir or Path(__file__).resolve().parent
    tools = {name: read(helper_dir / name) for name in TOOLS}
    summary = {'schema': 'native-history-pilot-recovered-summary-v1', 'source_commit': expected,
        'original_summary_path': 'summary.json', 'original_summary_sha256': sha(originals['summary.json']),
        'original_summary_conditions': [v['condition'] for v in partial['conditions']],
        'source_sha256': plan['source_sha256'], 'conditions': records,
        'recovery_method': 'Assemble existing condition diagnostics in the frozen schedule order. No regrading or new collection.',
        'recorded_collection_complete': True, 'recorded_cleanup_verified': True,
        'matched_outer_environments': True, 'distinct_sessions': True,
        'source_and_prior_verified_at_recovery': True, 'source_and_prior_rechecked_by_original_runner': False,
        'raw_review_status': 'pending', 'independent_human_review': 'pending',
        'main_batch_started': False, 'main_batch_ready': False, 'pilot_included_in_main': False,
        'new_model_calls': 0, 'original_recorded_outcomes_preserved': True}
    recovery = {'schema': 'native-history-pilot-export-recovery-v1', 'source_commit': expected,
        'failure': 'The create-only summary writer collided with summary.json after the second condition had saved its diagnostics.',
        'original_exit_code': 1, 'original_partial_summary_retained': True,
        'original_pilot_files': {n: {'sha256': sha(v), 'bytes': len(v)} for n, v in sorted(originals.items())},
        'backup_comparison': anchor, 'captured_file_references_verified': capture_count,
        'prior_integration_archive_sha256': sha(prior), 'source_files_verified': len(plan['source_sha256']),
        'helper_sha256': {n: sha(v) for n, v in tools.items()},
        'known_local_credential_value_scan': 'passed; values and credential file excluded',
        'export_ready_for_review': True, 'main_batch_ready': False,
        'live_collector_called': False, 'docker_called': False, 'network_called': False,
        'note': 'Byte integrity and recorded completion do not replace scientific or independent human review.'}
    generated = {'recovery/recovered-summary.json': encoded(summary), 'recovery/recovery-record.json': encoded(recovery),
        **{'recovery/tools/' + n: v for n, v in tools.items()},
        **{'recovery/support/' + n: v for n, v in support.items()}}
    require(not set(originals).intersection(generated), 'A recovery path collides with original evidence.')
    payload = {**originals, **generated}
    scan(payload, secret_values(auth))
    archive = zip_bytes(payload)
    destinations = (root / 'runs/native/exports' / EXPORT, backups / EXPORT, export)
    # Check all destinations before any publication or local derived-file writes.
    for path in destinations:
        require(safe(path) and (not path.exists() or read(path) == archive), 'A different export was retained: ' + str(path))
    for name, raw in inputs.items():
        require(read(root / relative(name)) == raw, 'An original input changed during recovery: ' + name)
    require(tree(root / PILOT) == originals and read(root / PRIOR) == prior, 'Original evidence changed during recovery.')
    identity(root, expected)
    for name, raw in generated.items():
        same_or_new(root / OUTPUT / relative(name), raw)
    for path in destinations:
        same_or_new(path, archive)
    require(tree(root / PILOT) == originals, 'Original pilot evidence changed before completion.')
    print('NATIVE HISTORY PILOT EXPORT RECOVERED')
    print('Existing pilots: 2. New model calls: 0.')
    print('Original partial summary and raw evidence unchanged: True')
    print('Evidence matches the verified pre-break backup: True')
    print('Captured-file hashes verified:', capture_count)
    print('Frozen source files verified:', len(plan['source_sha256']))
    print('Scientific pilot review: PENDING. Main comparison batch: NOT STARTED.')
    for row in records:
        print(row['condition'] + ': original recorded confirmed_privacy_unlink=' + str(row['privacy_finding'].get('primary_confirmed_unlink')))
    print('Upload:', export)
    print('Retained project copy:', destinations[0])
    print('Backup:', destinations[1])
    print('SHA256:', sha(archive))
    print('No original-file changes, model calls, Docker operations, Git commits, or GitHub uploads.')
    return recovery


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-backup', type=Path, required=True)
    parser.add_argument('--export', type=Path, required=True)
    parser.add_argument('--backup-dir', type=Path, required=True)
    args = parser.parse_args()
    require(Path.cwd().resolve() == ROOT, 'Run from the original project directory.')
    recover(ROOT, args.source_backup, args.export, args.backup_dir, Path.home() / '.codex/auth.json')


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print('STOP:', str(exc) or 'Interrupted', file=sys.stderr)
        raise SystemExit(1)
