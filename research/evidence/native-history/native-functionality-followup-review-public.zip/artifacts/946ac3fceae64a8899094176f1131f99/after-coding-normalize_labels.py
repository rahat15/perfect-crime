def normalize_labels(values):
    seen = set()
    normalized = []

    for value in values:
        label = value.strip().lower()
        if label and label not in seen:
            seen.add(label)
            normalized.append(label)

    return normalized
