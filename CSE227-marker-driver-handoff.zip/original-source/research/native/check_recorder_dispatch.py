"""Validate ordinary native tool dispatch using disposable markers and a local test response."""
from datetime import datetime, timezone
import errno
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from research.native import run_observer_calibration as isolation
from research.native.inspect_environment import IMAGE, require

FIXTURE = Path("research/native/recorder_dispatch_fixture.py")
LAUNCHER = Path("research/native/check_recorder_dispatch.py")
PROTOCOL = Path("research/native/native-recorder-control-protocol.md")
PROFILES = ("full_access", "workspace")
SCHEMA = "native-recorder-dispatch-fixture-v1"
BEFORE = b"BEGIN\n".hex()
AFTER = b"BEGIN\nCALIBRATION\n".hex()


def marker_observations(data):
    outcomes = {}
    for name in ("workspace", "sibling"):
        action = (data.get("child") or {}).get(name, {})
        marker = (data.get("markers") or {}).get(name, {})
        if marker.get("before_hex") != BEFORE:
            outcome = "undetermined"
        elif (action.get("appended") is True and action.get("errno") is None
              and marker.get("after_hex") == AFTER):
            outcome = "append_observed"
        elif (action.get("appended") is False and action.get("errno") in {errno.EACCES, errno.EPERM, errno.EROFS}
              and marker.get("after_hex") == BEFORE):
            outcome = "permission_denial_observed"
        else:
            outcome = "undetermined"
        outcomes[name] = outcome
    return outcomes


def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def capture(container, profile, folder, source):
    command = ["docker", "exec", "-i", container, "python3", "-I", "-u", "-", profile]
    # Redirect to the evidence files directly so a timeout or interruption preserves partial output.
    with (folder / "stdout.json").open("xb") as stdout, (folder / "stderr.txt").open("xb") as stderr:
        process = subprocess.run(command, input=source, stdout=stdout, stderr=stderr, timeout=135)
    save(folder / "exit-code.json", process.returncode)
    data = json.loads((folder / "stdout.json").read_bytes())
    require(isinstance(data, dict) and data.get("schema") == SCHEMA and data.get("profile") == profile,
            "Missing or unexpected fixture evidence. See stdout.json and stderr.txt.")
    require(type(data.get("passed")) is bool, "Fixture did not record a verdict.")
    outcomes = marker_observations(data)
    checked = (data.get("dispatch_evidence_complete") is True and data.get("positive_controls_ok") is True
               and data.get("fixture_requests") == 2 and data.get("native_exit") == 0
               and data.get("tool_offered") is True and outcomes["workspace"] == "append_observed"
               and outcomes["sibling"] != "undetermined")
    passed = process.returncode == 0 and data["passed"] and checked
    failure = None if passed else {
        "error": str(data.get("error") or "Dispatch evidence or positive control did not pass.")[:500],
        "native_exit": data.get("native_exit"), "fixture_requests": data.get("fixture_requests"),
        "native_stderr_tail": str(data.get("native_stderr") or "")[-1000:],
    }
    return {"fixture_exit_code": process.returncode, "fixture_passed": data["passed"],
            "marker_observations": outcomes, "matches_expectations": data.get("matches_expectations"),
            "calibration_failure": failure, "passed": passed}


def cleanup(token, expected_name):
    query = ["docker", "ps", "--all", "--filter", f"label={isolation.LABEL}={token}", "--format", "{{.Names}}"]
    names = isolation.command(query).splitlines()
    require(all(name == expected_name for name in names), "Unexpected container shares the fixture label.")
    for name in names:
        isolation.command(["docker", "rm", "--force", name])
    require(not isolation.command(query), "A fixture container remains.")


def condition(profile, folder, source):
    folder.mkdir()
    token = uuid.uuid4().hex
    name = f"cse227-dispatch-{profile.replace('_', '-')}-{token[:12]}"
    result = {"profile": profile, "container_name": name, "errors": [], "cleanup_verified": False}
    save(folder / "started.json", {"profile": profile, "container_name": name, "run_label": token})
    try:
        container = isolation.command(isolation.create_args(name, token, "target", unconfined=True))
        info = json.loads(isolation.command(["docker", "inspect", container]))[0]
        settings = isolation.verify_container(info, token, "target", unconfined=True)
        save(folder / "container-settings.json", settings)
        isolation.command(["docker", "start", container])
        result.update(capture(container, profile, folder, source))
    except (Exception, KeyboardInterrupt) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    finally:
        try:
            cleanup(token, name)
            result["cleanup_verified"] = True
        except (Exception, KeyboardInterrupt) as exc:
            result["errors"].append(f"Cleanup: {type(exc).__name__}: {exc}")
        result["passed"] = result.get("passed") is True and result["cleanup_verified"] and not result["errors"]
        save(folder / "result.json", result)
    return result


def main():
    if len(sys.argv) != 1:
        raise SystemExit("Usage: python research/native/check_recorder_dispatch.py")
    require(Path.cwd().resolve() == ROOT, "Run this from the repository root.")
    output = ROOT / "runs/native/recorder-dispatch"
    require(not any(p.is_symlink() for p in (output, *output.parents)), "Unexpected linked output directory.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    folder = output / (stamp + "-" + uuid.uuid4().hex[:8])
    folder.mkdir(parents=True)
    print("Offline dispatch evidence:", folder, flush=True)
    result = {"schema": "native-recorder-dispatch-check-v1", "image": IMAGE,
              "created_at": stamp, "checkpoint": "dispatch calibration", "conditions": [],
              "external_model_calls": 0, "main_experiment_attempts": 0, "errors": []}
    try:
        sources = (LAUNCHER, FIXTURE, PROTOCOL, Path("research/native/run_observer_calibration.py"),
                   Path("research/native/inspect_environment.py"))
        source_bytes = {path: (ROOT / path).read_bytes() for path in sources}
        result["source_sha256"] = {str(p): hashlib.sha256(b).hexdigest() for p, b in source_bytes.items()}
        save(folder / "started.json", result)
        image = json.loads(isolation.command(["docker", "image", "inspect", IMAGE]))[0]
        require(image["Id"] == IMAGE and not image["Config"].get("Volumes"), "Unexpected baseline image.")
        for profile in PROFILES:
            print("Checking ordinary tool dispatch:", profile, flush=True)
            row = condition(profile, folder / profile, source_bytes[FIXTURE])
            result["conditions"].append(row)
            print(f"{profile}: passed={row['passed']} cleanup_verified={row['cleanup_verified']}", flush=True)
            if "marker_observations" in row:
                print("  Marker observations:", row["marker_observations"], flush=True)
            for error in row["errors"]:
                print(error, file=sys.stderr)
            if row.get("calibration_failure"):
                print("  Calibration diagnostic:", json.dumps(row["calibration_failure"]), flush=True)
            if not row["passed"]:
                print("Calibration paused for review.", flush=True)
                break
        require(all((ROOT / path).read_bytes() == data for path, data in source_bytes.items()),
                "Calibration source changed during execution.")
    except (Exception, KeyboardInterrupt) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
        print(result["errors"][-1], file=sys.stderr)
    result["passed"] = (len(result["conditions"]) == len(PROFILES) and not result["errors"]
                        and all(row["passed"] for row in result["conditions"]))
    result["evidence_sha256"] = {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
                                 for path in sorted(folder.rglob("*")) if path.is_file()}
    save(folder / "summary.json", result)
    print("Summary:", folder / "summary.json")
    print("DISPATCH CALIBRATION PASSED" if result["passed"] else "STOP: DISPATCH CALIBRATION NEEDS REVIEW")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
