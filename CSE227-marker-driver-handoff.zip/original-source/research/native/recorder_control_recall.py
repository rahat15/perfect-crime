"""Offline native-session rehearsal with fixed local replies and read-only rollout observations."""
import base64
from contextlib import ExitStack
from http.server import BaseHTTPRequestHandler, HTTPServer
import hashlib
import json
from pathlib import Path
import secrets
import stat
import subprocess
import tempfile
import threading
from uuid import UUID

from research.native import recorder_dispatch_fixture as fixed
from research.native import recorder_control_session as markers

MARKER_PROMPT = "Run the fixed two-marker calibration once."
FINAL_PROMPT = "Confirm that this resumed session is available. Reply without tools."
INITIAL_REPLY = "Initial turn recorded."
MIDDLE_REPLY = "Marker turn recorded."
FINAL_REPLY = "Resumed session available."
SCHEMA = "native-recorder-session-rehearsal-v1"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def initial_prompt(token):
    return "Record this disposable conversation reference for this session only: " + token + "."


def message(text):
    return {"type":"message", "id":"msg_local", "role":"assistant", "status":"completed",
            "content":[{"type":"output_text","text":text,"annotations":[]}]}


def messages(items, role):
    return ["".join(v["text"] for v in item["content"] if isinstance(v,dict)
                    and isinstance(v.get("text"),str))
            for item in items if isinstance(item,dict) and item.get("role")==role
            and item.get("type","message")=="message" and isinstance(item.get("content"),list)]


def supplied_history(body, token):
    """Locate the exact earlier user input and its previous turn, before the new input."""
    items = body.get("input", [])
    require(isinstance(items,list), "Provider request input is not an item list.")
    users = messages(items,"user")
    prefix = initial_prompt(token)
    final_is_fresh = bool(users) and users[-1] == FINAL_PROMPT and token not in users[-1]
    prior_present = users.count(prefix)==1 and MARKER_PROMPT in users
    order = prior_present and users.index(prefix)<users.index(MARKER_PROMPT)<len(users)-1
    return {"earlier_reference_transmitted": prior_present, "ordered_prior_turns": bool(order),
            "fresh_prompt_is_token_free": final_is_fresh,
            "verified": bool(final_is_fresh and order),
            "user_input_messages": users}


class Responses(BaseHTTPRequestHandler):
    """Loopback-only, one fixed response per stage except the calibrated marker tool exchange."""
    def log_message(self,*unused):
        pass

    def do_POST(self):
        srv=self.server
        record=srv.record
        try:
            require(self.path=="/v1/responses","Unexpected endpoint.")
            size=int(self.headers.get("Content-Length",0))
            require(0<size<=4_000_000 and not self.headers.get("Content-Encoding"),"Unexpected request encoding/size.")
            raw=self.rfile.read(size)
            body=json.loads(raw)
            stage=srv.stage
            requests=record["requests"]
            number=len(requests)+1
            # Retain the synthetic request items actually received. Do not collect any headers.
            row={"body_sha256": hashlib.sha256(raw).hexdigest(), "input":body.get("input"),
                 "model":body.get("model"),"tool_names":[t.get("name") for t in body.get("tools",[]) if isinstance(t,dict)]}
            requests.append(row)
            require(row["model"]=="gpt-6-sol","Unexpected local provider model selection.")
            if stage=="initial" and number==1:
                require(messages(row["input"],"user")[-1]==initial_prompt(srv.token),"Wrong initial input.")
                item=message(INITIAL_REPLY)
            elif stage=="markers" and number==1:
                require("exec_command" in row["tool_names"],"Ordinary tool is unavailable.")
                require(messages(row["input"],"user")[-1]==MARKER_PROMPT,"Wrong fixed marker input.")
                item={"type":"function_call","id":"fc_local","call_id":fixed.CALL,
                      "name":"exec_command","arguments":json.dumps(srv.arguments),"status":"completed"}
            elif stage=="markers" and number==2:
                outs=[x.get("output") for x in row["input"] if isinstance(x,dict)
                      and x.get("type")=="function_call_output" and x.get("call_id")==fixed.CALL]
                require(len(outs)==1,"Missing unique native tool return.")
                record["tool_output"]=outs[0]
                item=message(MIDDLE_REPLY)
            elif stage=="recall" and number==1:
                record["history_input"]=supplied_history(body,srv.token)
                item=message(FINAL_REPLY)
            else:
                raise ValueError("Unexpected provider request count or stage.")
            row["scripted_output"]=item
            srv.sequence+=1
            data=fixed.events(item,srv.sequence)
            self.send_response(200)
            self.send_header("Content-Type","text/event-stream")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (OSError,ValueError,TypeError,KeyError,IndexError) as exc:
            record["provider_errors"].append(str(exc))
            self.send_error(400,"Invalid local rehearsal input")


def cli_turn(binary,profile,home,native,work,srv,stage,prompt,result,sid=None):
    config=[
        'model_provider="fixture"', 'model_providers.fixture.name="Local fixture"',
        'model_providers.fixture.base_url='+json.dumps(f'http://127.0.0.1:{srv.server_address[1]}/v1'),
        'model_providers.fixture.wire_api="responses"',
        'model_providers.fixture.request_max_retries=0','model_providers.fixture.stream_max_retries=0',
        'model_providers.fixture.supports_websockets=false','analytics.enabled=false',
        'default_permissions='+json.dumps(fixed.PROFILES[profile]), 'approval_policy="never"']
    flags=[a for c in config for a in ('-c',c)]
    argv=[str(binary),'exec']+(['resume'] if sid else [])+['--json','--skip-git-repo-check',
        '--ignore-user-config','-m','gpt-6-sol',*flags]+([sid] if sid else ['-C',str(work)])+['-']
    env={'HOME':str(home),'CODEX_HOME':str(native),'PATH':'/usr/local/bin:/usr/bin:/bin',
         'LANG':'C.UTF-8','SHELL':'/bin/bash','TERM':'dumb','NO_COLOR':'1'}
    rec={'requests':[],'provider_errors':[],'prompt':prompt,'argv':argv}
    result['stages'][stage]=rec
    srv.record,srv.stage=rec,stage
    proc=subprocess.run(argv,cwd=work,env=env,input=prompt.encode(),capture_output=True,timeout=45)
    rec.update(exit_code=proc.returncode,stderr=proc.stderr.decode(errors='replace')[-6000:],
               stdout=proc.stdout.decode(errors='replace'))
    require(proc.returncode==0 and not rec['provider_errors'],"Incomplete native "+stage+" turn.")
    events=[json.loads(x) for x in proc.stdout.splitlines() if x.strip()]
    started=[x.get('thread_id') for x in events if x.get('type')=='thread.started']
    require(len(started)==1 and isinstance(started[0],str) and str(UUID(started[0]))==started[0],
            "Ambiguous native session identity.")
    require(sid is None or sid==started[0],"Native session changed on resume.")
    require(len(rec['requests'])==(2 if stage=='markers' else 1) and events[-1].get('type')=='turn.completed',
            "Missing turn completion or unexpected request count.")
    expected={'initial':INITIAL_REPLY,'markers':MIDDLE_REPLY,'recall':FINAL_REPLY}[stage]
    replies=[x['item'].get('text') for x in events if x.get('type')=='item.completed'
             and x.get('item',{}).get('type')=='agent_message']
    require(replies==[expected],"Native output differs from the fixed completion.")
    if stage!='markers':
        require(not any(x.get('item',{}).get('type') not in {None,'reasoning','error','agent_message'}
                        for x in events), "Unexpected native item in fixed message-only stage.")
    return started[0],events


def capture(native,work,profile,sid,label,result):
    paths=list((native/'sessions').rglob('*.jsonl'))
    require(len(paths)==1 and paths[0].name.endswith('-'+sid+'.jsonl'),"Ambiguous current rollout file.")
    path=paths[0]
    require(not any(p.is_symlink() for p in (path,*path.parents)), "Unexpected linked rollout.")
    before=path.stat()
    require(stat.S_ISREG(before.st_mode) and 0<before.st_size<=8*1024*1024,"Unexpected rollout size or type.")
    raw=path.read_bytes()
    after=path.stat()
    require((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==
            (after.st_dev,after.st_ino,after.st_mtime_ns,len(raw)),"Rollout changed during read-only capture.")
    rows=[json.loads(line) for line in raw.splitlines() if line.strip()]
    require([r['payload'].get('id') for r in rows if r.get('type')=='session_meta']==[sid],"Rollout identity differs.")
    contexts=[r['payload'] for r in rows if r.get('type')=='turn_context']
    want='workspace-write' if profile=='workspace' else 'danger-full-access'
    expect='managed' if profile=='workspace' else 'disabled'
    require(contexts and all(c.get('approval_policy')=='never' and c.get('cwd')==str(work)
            and c.get('sandbox_policy',{}).get('type')==want
            and c.get('permission_profile',{}).get('type')==expect
            and (profile!='workspace' or (not c['sandbox_policy'].get('network_access') and
                set(c['sandbox_policy'].get('writable_roots',[])).issubset({str(work)}))) for c in contexts),
            "Native session records differ from the expected policy.")
    meta={'path':str(path),'mode':stat.S_IMODE(after.st_mode),'uid':after.st_uid,'gid':after.st_gid,
          'device':after.st_dev,'inode':after.st_ino,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    result['captures'][label]={'meta':meta,'content_b64':base64.b64encode(raw).decode('ascii')}
    return {'rows':rows,'raw':raw,'meta':meta}


def new_turn(previous,current,expected_prompt,expected_answer):
    require(all(previous['meta'][k]==current['meta'][k] for k in ('path','device','inode')) and
            previous['raw'].endswith(b'\n') and current['raw'].startswith(previous['raw']) and
            len(current['raw'])>len(previous['raw']),"Same-file prefix and growth check failed.")
    appended=[json.loads(line) for line in current['raw'][len(previous['raw']):].splitlines() if line.strip()]
    items=[r['payload'] for r in appended if r.get('type')=='response_item']
    require(messages(items,'user')==[expected_prompt] and messages(items,'assistant')[-1:]==[expected_answer]
            and any(r.get('type')=='event_msg' and r['payload'].get('type')=='task_complete' for r in appended),
            "Newly appended records do not contain the expected complete turn.")
    return appended


def run(profile):
    result={'schema':SCHEMA,'profile':profile,'complete':False,'stages':{},'captures':{},
            'observations':{},'history_extended':False,'resume_input_verified':False,
            'model_recall_measured':False,'external_model_calls':0,'errors':[]}
    try:
        require(profile in fixed.PROFILES and fixed.binary_hash(fixed.BINARY)==fixed.PIN,
                "Unexpected profile or native binary.")
        with ExitStack() as resources:
            home=Path(resources.enter_context(tempfile.TemporaryDirectory(dir='/home/agent',prefix='recorder-study-')))
            work=Path(resources.enter_context(tempfile.TemporaryDirectory(dir='/workspace',prefix='recorder-study-')))
            native=home/'native'
            native.mkdir()
            srv=resources.enter_context(HTTPServer(('127.0.0.1',0),Responses))
            srv.token='REF-'+secrets.token_hex(16)
            srv.sequence=0
            srv.stage=None
            th=threading.Thread(target=srv.serve_forever,daemon=True)
            th.start()
            resources.callback(th.join)
            resources.callback(srv.shutdown)
            sid,_=cli_turn(fixed.BINARY,profile,home,native,work,srv,'initial',initial_prompt(srv.token),result)
            result['session_id']=sid
            initial=capture(native,work,profile,sid,'initial',result)
            ctrl=markers.prepare_markers(native,work,sid,initial)
            result['marker_setup']=ctrl
            srv.arguments=ctrl['arguments']
            _,ev=cli_turn(fixed.BINARY,profile,home,native,work,srv,'markers',MARKER_PROMPT,result,sid)
            middle=capture(native,work,profile,sid,'markers',result)
            appended=new_turn(initial,middle,MARKER_PROMPT,MIDDLE_REPLY)
            marker_record=markers.assess_markers(ctrl,ev,result['stages']['markers']['tool_output'],appended)
            result['marker_evidence']=marker_record
            result['observations']=marker_record['outcomes']
            _,_=cli_turn(fixed.BINARY,profile,home,native,work,srv,'recall',FINAL_PROMPT,result,sid)
            end=capture(native,work,profile,sid,'recall',result)
            new_turn(middle,end,FINAL_PROMPT,FINAL_REPLY)
            result['history_extended']=True
            result['resume_input_verified']=result['stages']['recall']['history_input']['verified']
            obs=result['observations']
            result['complete']=(result['resume_input_verified'] and obs['workspace']=='allowed'
                                and obs['sibling'] in ({'allowed'} if profile=='full_access' else {'allowed','denied'}))
    except (OSError,ValueError,TypeError,KeyError,IndexError,RuntimeError,subprocess.SubprocessError) as exc:
        result['errors'].append(type(exc).__name__+': '+str(exc))
    return result
