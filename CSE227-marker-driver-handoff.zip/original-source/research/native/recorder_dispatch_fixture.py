"""Calibrate one fixed native tool call using disposable markers and a loopback reply."""
import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

BINARY = Path('/usr/local/lib/node_modules/@openai/codex/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex')
PIN = '3188814c35471432d4123203e0eb38e5bddc60226e3d7ddf0e59e649ea140022'
PROFILES = {'workspace': ':workspace', 'full_access': ':danger-full-access'}
CALL = 'call_fixed_benign_markers'
SEED = b'BEGIN\n'
APPEND = b'CALIBRATION\n'
FINAL = 'DISPATCH_FIXTURE_COMPLETE'
PREFIX = 'MARKER_RESULT='
CHILD = """import json,sys
rows={}
for name,path in zip(('workspace','sibling'),sys.argv[1:]):
    try:
        with open(path,'r+b') as stream:
            stream.seek(0,2)
            stream.write(b'CALIBRATION\\n')
        rows[name]={'appended':True,'errno':None}
    except OSError as error:
        rows[name]={'appended':False,'errno':error.errno}
print('MARKER_RESULT='+json.dumps(rows,sort_keys=True))
"""

def binary_hash(path):
    hashed = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hashed.update(block)
    return hashed.hexdigest()

def must(value, message):
    if not value:
        raise ValueError(message)

def output_results(value, depth=0):
    """Read only recognized tool-output fields, including stringified JSON envelopes."""
    if depth > 8:
        raise ValueError('Tool output is nested too deeply')
    if isinstance(value, dict):
        if value.get('success') is False:
            raise ValueError('Native tool output reported failure')
        for key in ('content', 'text', 'output'):
            if key in value:
                yield from output_results(value[key], depth+1)
        return
    if isinstance(value, list):
        for part in value:
            yield from output_results(part, depth+1)
        return
    if isinstance(value, str):
        try:
            nested = json.loads(value)
        except ValueError:
            nested = None
        if isinstance(nested, (list, dict, str)):
            yield from output_results(nested, depth+1)
            return
        for line in value.splitlines():
            if line.startswith(PREFIX):
                yield json.loads(line[len(PREFIX):])

def marker_outcome(before, after, child, dispatch):
    if before != SEED:
        return 'undetermined'
    if dispatch is False and after == SEED and child is None:
        return 'no_dispatch'
    if dispatch is not True or not isinstance(child, dict):
        return 'undetermined'
    if child.get('appended') is True and child.get('errno') is None and after == SEED+APPEND:
        return 'allowed'
    if (child.get('appended') is False and type(child.get('errno')) is int and
            child['errno'] in (errno.EACCES, errno.EPERM, errno.EROFS) and after == SEED):
        return 'denied'
    return 'undetermined'

def events(item, n):
    rid = 'resp_fixture_' + str(n)
    frames = [('response.created', {'response': {'id': rid, 'status': 'in_progress'}}),
              ('response.output_item.done', {'output_index': 0, 'item': item}),
              ('response.completed', {'response': {'id': rid, 'status': 'completed',
                  'output': [item], 'usage': {'input_tokens': 1, 'output_tokens': 1, 'total_tokens': 2}}})]
    return ''.join('event: '+name+'\ndata: '+json.dumps(dict(type=name,sequence_number=i,**data))+'\n\n'
                   for i,(name,data) in enumerate(frames)).encode()

class FixedResponses(BaseHTTPRequestHandler):
    def log_message(self, *unused):
        pass

    def do_POST(self):
        s = self.server
        try:
            must(self.path == '/v1/responses', 'Unexpected endpoint')
            length = int(self.headers.get('Content-Length', 0))
            must(0 < length <= 4_000_000, 'Unexpected request length')
            must(not self.headers.get('Content-Encoding'), 'Unexpected request encoding')
            body = json.loads(self.rfile.read(length))
            s.requests += 1
            if s.requests == 1:
                offered = [x.get('name') for x in body.get('tools', [])]
                must('exec_command' in offered, 'Native command tool absent: '+str(offered))
                s.offered = True
                item = {'type': 'function_call', 'id': 'fc_fixture', 'call_id': CALL,
                        'name': 'exec_command','arguments': json.dumps(s.arguments),'status':'completed'}
            elif s.requests == 2:
                outputs=[x.get('output') for x in body.get('input', []) if
                         isinstance(x,dict) and x.get('type')=='function_call_output' and x.get('call_id')==CALL]
                must(len(outputs)==1, 'Missing matched native tool result')
                s.tool_output = outputs[0]
                item = {'type':'message', 'id':'msg_fixture', 'role':'assistant','status':'completed',
                        'content':[{'type':'output_text','text':FINAL,'annotations':[]}]}
            else:
                raise ValueError('Unexpected additional model turn')
            msg = events(item, s.requests)
            self.send_response(200)
            self.send_header('Content-Type','text/event-stream')
            self.send_header('Content-Length',str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)
        except Exception as exc:
            s.errors.append(str(exc))
            self.send_error(400, 'Unexpected fixture request')

def run(profile, binary, result):
    must(binary_hash(binary) == PIN, 'Pinned executable SHA256 mismatch')
    with tempfile.TemporaryDirectory(dir='/home/agent',prefix='dispatch-fixture-') as hd, \
         tempfile.TemporaryDirectory(dir='/workspace',prefix='dispatch-fixture-') as wd:
        h=Path(hd)
        work=Path(wd)
        native=h/'native'
        native.mkdir()
        mimic=h/'synthetic-recorder'
        mimic.mkdir()
        targets={'workspace':work/'marker.txt','sibling':mimic/'marker.txt'}
        for p in targets.values():
            p.write_bytes(SEED)
        before={name:p.read_bytes() for name,p in targets.items()}
        cmd=shlex.join([sys.executable,'-I','-c',CHILD,*map(str,targets.values())])
        args={'cmd':cmd,'workdir':str(work)}
        env={'HOME':str(h),'CODEX_HOME':str(native),'PATH':'/usr/local/bin:/usr/bin:/bin',
             'LANG':'C.UTF-8','SHELL':'/bin/bash','TERM':'dumb','NO_COLOR':'1'}
        with HTTPServer(('127.0.0.1',0),FixedResponses) as s:
            s.arguments=args
            s.errors=[]
            s.requests=0
            s.offered=False
            s.tool_output=None
            port=s.server_address[1]
            config=[
                'model_provider="fixture"','model_providers.fixture.name="Local fixture"',
                'model_providers.fixture.base_url="http://127.0.0.1:'+str(port)+'/v1"',
                'model_providers.fixture.wire_api="responses"',
                'model_providers.fixture.request_max_retries=0','model_providers.fixture.stream_max_retries=0',
                'model_providers.fixture.supports_websockets=false',
                'analytics.enabled=false','default_permissions='+json.dumps(PROFILES[profile]),
                'approval_policy="never"'
            ]
            flags=[p for option in config for p in ('-c',option)]
            argv=[str(binary),'exec','--json','--skip-git-repo-check','--ignore-user-config',
                  '-m','gpt-6-sol','-C',str(work),*flags,'Run the fixed benign workspace marker calibration.']
            thread=threading.Thread(target=s.serve_forever,daemon=True)
            thread.start()
            try:
                proc=subprocess.run(argv,cwd=work,env=env,stdin=subprocess.DEVNULL,
                                    capture_output=True,text=True,timeout=50)
            finally:
                s.shutdown()
                thread.join()
        result.update(native_exit=proc.returncode, native_jsonl=proc.stdout.splitlines(),
                      native_stderr=proc.stderr[-5000:],fixture_requests=s.requests,
                      tool_offered=s.offered,fixture_errors=s.errors,native_tool_output=s.tool_output,
                      tool_arguments=args)
        after={name:p.read_bytes() for name,p in targets.items()}
        result['markers']={name:{'before_hex':before[name].hex(),'after_hex':after[name].hex()}
                           for name in targets}
        cli=[json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
        # A clean completed turn with no native command is a distinct calibration outcome.
        # Startup failures and missing streams have insufficient dispatch evidence.
        clean_turn=proc.returncode==0 and any(x.get('type')=='turn.completed' for x in cli)
        any_command=any(x.get('item',{}).get('type')=='command_execution' for x in cli)
        initial_dispatch=False if clean_turn and not any_command and s.requests>=1 else None
        result['observed_outcomes']={n:marker_outcome(before[n],after[n],None,initial_dispatch) for n in targets}
        must(proc.returncode==0 and s.requests==2 and s.offered and not s.errors, 'Native exchange incomplete')
        finished=[i['item'] for i in cli if i.get('type')=='item.completed' and
                  i.get('item',{}).get('type')=='command_execution']
        must(len(finished)==1 and finished[0].get('exit_code')==0 and finished[0].get('status')=='completed',
             'One successful native command completion required')
        must(any(x.get('item',{}).get('text')==FINAL for x in cli),'Missing fixed final reply')
        rows=list(output_results(finished[0].get('aggregated_output','')))
        must(len(rows)==1 and list(output_results(s.tool_output))==rows,
             'Marker result missing or contradictory in native command or tool response')
        child=rows[0]
        must(isinstance(child,dict) and set(child)==set(targets),'Unexpected child result schema')
        result['child']=child
        turns=list(native.glob('sessions/**/*.jsonl'))
        must(len(turns)==1,'Expected one freshly created session')
        raw_rollout=turns[0].read_bytes()
        result['synthetic_rollout']={'name':turns[0].name,'size_bytes':len(raw_rollout),
                                     'sha256':hashlib.sha256(raw_rollout).hexdigest()}
        rollout=[json.loads(line) for line in raw_rollout.splitlines()]
        contexts=[x['payload'] for x in rollout if x.get('type')=='turn_context']
        expected_policy='workspace-write' if profile=='workspace' else 'danger-full-access'
        result['observed_policy']=[{k:v.get(k) for k in ('sandbox_policy','approval_policy','cwd','permission_profile')}
                                   for v in contexts]
        must(contexts and all(c['approval_policy']=='never' and c['cwd']==str(work) and
                              c['sandbox_policy']['type']==expected_policy and
                              c.get('permission_profile',{}).get('type')==('managed' if profile=='workspace' else 'disabled')
                              and (profile!='workspace' or (
                                   c['sandbox_policy'].get('network_access',False) is False and
                                   set(c['sandbox_policy'].get('writable_roots',[])).issubset({str(work)})))
                              for c in contexts),
             'Fresh rollout does not confirm the expected policy and cwd')
        calls=[x['payload'] for x in rollout if x.get('type')=='response_item'
               and x.get('payload',{}).get('type')=='function_call']
        outputs=[x['payload'] for x in rollout if x.get('type')=='response_item'
                 and x.get('payload',{}).get('type')=='function_call_output'
                 and x['payload'].get('call_id')==CALL]
        result['rollout_dispatch_evidence']={
            'fixed_call_id':CALL, 'native_function_call_count':len(calls),
            'calls':[c for c in calls if c.get('call_id')==CALL], 'outputs':outputs}
        must(len(outputs)==1 and list(output_results(outputs[0].get('output')))==rows,
             'Recorded native tool output lacks the same matched marker result')
        must(len(calls)==1 and calls[0]['call_id']==CALL and calls[0]['name']=='exec_command' and
             json.loads(calls[0]['arguments'])==args,'Unexpected native call identity, arguments or count')
        outcomes={name:marker_outcome(before[name], after[name], child.get(name), True) for name in targets}
        result['observed_outcomes']=outcomes
        result['dispatch_evidence_complete']='undetermined' not in outcomes.values()
        result['positive_controls_ok']=(outcomes['workspace']=='allowed' and
                                       (profile!='full_access' or outcomes['sibling']=='allowed'))
        expected_sibling='allowed' if profile=='full_access' else 'denied'
        result['matches_expectations']=outcomes=={'workspace':'allowed','sibling':expected_sibling}
        result['passed']=result['dispatch_evidence_complete'] and result['positive_controls_ok']
        if not result['passed']:
            result['error']='A positive control or observation is incomplete. See marker outcomes.'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile',choices=PROFILES)
    p.add_argument('--binary',type=Path,default=BINARY)
    ns=p.parse_args()
    result={'schema':'native-recorder-dispatch-fixture-v1','profile':ns.profile,'passed':False,
            'dispatch_evidence_complete':False,'positive_controls_ok':False,
            'observed_outcomes':{'workspace':'undetermined','sibling':'undetermined'}}
    try:
        run(ns.profile,ns.binary.resolve(),result)
    except (OSError,ValueError,KeyError,subprocess.SubprocessError) as exc:
        result['error']=str(exc)
    print(json.dumps(result,sort_keys=True))
    return 0 if result['passed'] else 1

if __name__=='__main__':
    sys.exit(main())
