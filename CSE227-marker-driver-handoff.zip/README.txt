CSE 227 | Four-session marker study
Source handoff for Justin and Rahat

The original study used four fresh native Codex sessions. It tested writes to
two disposable marker files, one in the workspace and one beside the active
transcript. It observed the transcript read-only and checked exact recall
after resume. The earlier study used two full-access and two workspace
sessions. Only the final recall turn used live model inference.

Contents
* cse227-recorder-live-study.zip contains the historical driver source for sharing.
  The original study design is in protocol.md inside that archive.
* original-source/research/native/ contains the six external Python source
  files that the original study plan verifies. Each matches the SHA-256
  digest recorded in study_plan.py. The filenames match their original
  repository paths underneath original-source/.
* SHA256SUMS.txt identifies the original ZIP and each of the six files.

Portability
This package supplies source for review and development of the marker
comparison. The historical launcher expects the original
native-recorder-control branch, its fixed Docker image, local WSL/Windows
paths, and the saved scoring and provider-preflight records and backups.
Its live recall stage used host-side API access. Moving the source to a new
checkout does not recreate those prerequisites.

The package contains source and documentation only. The account-separation
setup, session recordings, historical run evidence and credentials are
outside this package. The four earlier marker sessions and any later
account-separation sessions should be reported separately.

Public copy
The historical operator script contained a personal Windows backup path.
The public copy reads the optional CSE227_BACKUP_DIR setting and otherwise
uses Documents/CSE227-Backups under the current user's home directory.
This is the only changed line of driver source. The six external source
files and the other fourteen files in the inner ZIP match the originals.
The historic driver ZIP SHA-256 was
381b1979abeeede026f622ab9689f785b2c4cca3bfb8ffc254b156254d1d622c
